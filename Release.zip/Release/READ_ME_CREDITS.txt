This exploit was created by Dragsploit, I am solo developer and only developer for this exploit.

DO NOT MODIFY OR REDISTRIBUTE MY EXPLOIT!


Thanks to the CheatSquad team for providing the required API to make this exploit possible. :)


AND MOST IMPORTANTLY.  Thank you to the wonderful server staff and members of the server for being with me through the development of Dragsploit!

Official Discord: https://discord.gg/zqzAW5G